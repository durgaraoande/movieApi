package com.abdr.auth.entities;

public enum UserRole {
        USER,
        ADMIN
}
