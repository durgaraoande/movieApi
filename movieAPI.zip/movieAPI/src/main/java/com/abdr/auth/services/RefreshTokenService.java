package com.abdr.auth.services;

import com.abdr.auth.entities.RefreshToken;
import com.abdr.auth.entities.User;
import com.abdr.auth.repositories.RefreshTokenRepository;
import com.abdr.auth.repositories.UserRepository;
import com.abdr.exceptions.RefreshTokenExpiredException;
import com.abdr.exceptions.RefreshTokenNotFound;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
public class RefreshTokenService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;

    public RefreshTokenService(UserRepository userRepository, RefreshTokenRepository refreshTokenRepository) {
        this.userRepository = userRepository;
        this.refreshTokenRepository = refreshTokenRepository;
    }

    public RefreshToken createRefreshToken(String email){
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UsernameNotFoundException("User not found with email : " + email));

        RefreshToken refreshToken=user.getRefreshToken();

        if(refreshToken==null){
            refreshToken=RefreshToken.builder()
                    .refreshToken(UUID.randomUUID().toString())
                    .expirationTime(Instant.now().plusMillis(4 * 60 * 1000))
                    .user(user)
                    .build();
            refreshTokenRepository.save(refreshToken);
        }
        return refreshToken;
    }

    public RefreshToken verifyRefreshToken(String refreshToken) throws RefreshTokenExpiredException {
        RefreshToken refToken=refreshTokenRepository.findByRefreshToken(refreshToken).orElseThrow(()->new RefreshTokenNotFound("Refresh Token not found! "));

        if(refToken.getExpirationTime().compareTo(Instant.now())<0){

            refreshTokenRepository.deleteByRefreshToken(refToken.getRefreshToken());
            System.out.println("deleted refToken "+refToken);
            throw new RefreshTokenExpiredException("Refresh Token Expired! ");
        }
        System.out.println(refToken);

        return refToken;
    }
}
