package com.abdr.controller;

import com.abdr.auth.entities.ForgotPassword;
import com.abdr.auth.entities.User;
import com.abdr.auth.repositories.ForgotPasswordRepo;
import com.abdr.auth.repositories.UserRepository;
import com.abdr.auth.utils.ChangePassword;
import com.abdr.dto.MailBody;
import com.abdr.exceptions.InvalidOtpException;
import com.abdr.service.EmailService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Date;
import java.util.Objects;
import java.util.Random;

@RestController
@RequestMapping("forgotPassword")
public class ForgotPasswordController {
    private final UserRepository userRepository;
    private final EmailService emailService;
    private final ForgotPasswordRepo forgotPasswordRepo;
    private final PasswordEncoder passwordEncoder;

    public ForgotPasswordController(UserRepository userRepository, EmailService emailService, ForgotPasswordRepo forgotPasswordRepo, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.forgotPasswordRepo = forgotPasswordRepo;
        this.passwordEncoder = passwordEncoder;
    }

    //send mail for email verification
    @PostMapping("/verifyMail/{mail}")
    public ResponseEntity<String> verifyEmail(@PathVariable String mail){
        User user=userRepository.findByEmail(mail).orElseThrow(()->new UsernameNotFoundException("No user found for "+mail));

        // Check if an OTP request was made recently
        ForgotPassword existingFp = forgotPasswordRepo.findByUser(user).orElse(null);

        if(existingFp != null && existingFp.getExpirationTime().after(Date.from(Instant.now()))){
            return new ResponseEntity<>("OTP has already sent to respective mail. Please check your mail box.", HttpStatus.TOO_MANY_REQUESTS);
        }

        int otp=otpGenerator();
        MailBody mailBody =MailBody.builder()
                .to(mail)
                .text("This is the OTP for your Forget Password Reset : "+otp)
                .subject("OTP for Forgot Password Request")
                .build();

        ForgotPassword fp=ForgotPassword.builder()
                .otp(otp)
                .expirationTime(new Date(System.currentTimeMillis()+ 70 * 1000))
                .user(user)
                .build();

        emailService.sendSimpleMessage(mailBody);
        forgotPasswordRepo.save(fp);

        return ResponseEntity.ok("Email sent for verification");
    }

    @PostMapping("verifyOtp/{otp}/{email}")
    public ResponseEntity<String> verifYOtp(@PathVariable String email,@PathVariable Integer otp){
        User user=userRepository.findByEmail(email).orElseThrow(()->new UsernameNotFoundException("No user found for "+email));

        ForgotPassword fp = forgotPasswordRepo.findByOtpAndUser(otp, user).orElseThrow(() -> new InvalidOtpException("Invalid OTP for email: " + email));

        if(fp.getExpirationTime().before(Date.from(Instant.now()))){
            forgotPasswordRepo.deleteById(fp.getFpid());
            return new ResponseEntity<>("OTP has expired", HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok("OTP verified! ");
    }

    @PostMapping("/changePassword/{email}")
    public ResponseEntity<String> changePasswordHandler(@RequestBody ChangePassword changePassword,@PathVariable String email){
        if(!Objects.equals(changePassword.password(),changePassword.repeatPassword())){
            return new ResponseEntity<>("Please enter the password again! ",HttpStatus.EXPECTATION_FAILED);
        }
        String encodedPass=passwordEncoder.encode(changePassword.password());
        userRepository.updatePassword(email,encodedPass);

        return ResponseEntity.ok("Password has been changes! ");
    }

    private Integer otpGenerator(){
        Random random=new Random();
        return random.nextInt(100_100,999_999);
    }
}
