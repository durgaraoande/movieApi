package com.abdr.controller;

import com.abdr.auth.entities.RefreshToken;
import com.abdr.auth.entities.User;
import com.abdr.auth.services.JwtService;
import com.abdr.auth.services.RefreshTokenService;
import com.abdr.auth.utils.AuthResponse;
import com.abdr.auth.utils.LoginRequest;
import com.abdr.auth.utils.RefreshTokenRequest;
import com.abdr.auth.utils.RegisterRequest;
import com.abdr.exceptions.RefreshTokenExpiredException;
import com.abdr.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/auth/")
public class AuthController {
    private final AuthService authService;
    private final RefreshTokenService refreshTokenService;
    private final JwtService jwtService;

    public AuthController(AuthService authService, RefreshTokenService refreshTokenService, JwtService jwtService) {
        this.authService = authService;
        this.refreshTokenService = refreshTokenService;
        this.jwtService = jwtService;
    }

    @PostMapping("register")
    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest registerRequest){
        return ResponseEntity.ok(authService.register(registerRequest));
    }

    @PostMapping("login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest loginRequest){
        return ResponseEntity.ok(authService.login(loginRequest));
    }

    @PostMapping("refresh")
    public ResponseEntity<AuthResponse> refreshToken(@RequestBody RefreshTokenRequest refreshTokenRequest) throws RefreshTokenExpiredException {
        RefreshToken refreshToken=refreshTokenService.verifyRefreshToken(refreshTokenRequest.getRefreshToken());

        User user=refreshToken.getUser();

        String accessToken = jwtService.generateToken(user.getUsername());

        return ResponseEntity.ok(AuthResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken.getRefreshToken())
                .build());
    }
}
