package com.abdr.exceptions;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.security.SignatureException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MovieNotFoundException.class)
    public ProblemDetail emptyFileExceptionHandler(MovieNotFoundException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, e.getMessage());
    }

    @ExceptionHandler(FileExistsException.class)
    public ProblemDetail emptyFileExceptionHandler(FileExistsException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(EmptyFileException.class)
    public ProblemDetail emptyFileExceptionHandler(EmptyFileException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    //for validation at controller layer , we should use @Valid annotation for RequestBody
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ProblemDetail handleValidationExceptions(MethodArgumentNotValidException ex) {
        // Collect field-specific error messages
        Map<String, String> errors = new HashMap<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.put(error.getField(), error.getDefaultMessage());
        }

        // Create a ProblemDetail instance with a BAD_REQUEST status and detailed error messages
        ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problemDetail.setDetail("Validation failed for one or more fields.");
        problemDetail.setProperty("errors", errors);

        return problemDetail;
    }

    //for validation at the persistence level at dao level checks constrains of a model to validate like @NotBlack. @NotNull
    @ExceptionHandler(ConstraintViolationException.class)
    public ProblemDetail handleValidationErrors(ConstraintViolationException e) {
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
        Map<String, String> errors = new HashMap<>();

        // Extract field names and messages from ConstraintViolation objects
        for (ConstraintViolation<?> violation : violations) {
            String fieldName = violation.getPropertyPath().toString(); // Gets the path of the invalid field
            String message = violation.getMessage(); // Gets the error message
            errors.put(fieldName, message);
        }

        // Build a user-friendly response
        ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        problemDetail.setDetail("Validation failed for one or more fields.");
        problemDetail.setProperty("errors", errors);

        return problemDetail;
    }

    @ExceptionHandler(UsernameNotFoundException.class)
    public ProblemDetail usernameNotFoundExceptionHandler(UsernameNotFoundException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(RefreshTokenExpiredException.class)
    public ProblemDetail refreshTokenExpiredExceptionHandler(RefreshTokenExpiredException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(RefreshTokenNotFound.class)
    public ProblemDetail refreshTokenNotFoundExceptionHandler(RefreshTokenNotFound e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(SecretKeyGeneratingException.class)
    public ProblemDetail secretKeyGeneratingExceptionHandler(SecretKeyGeneratingException e) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(JwtAndSignatureHandler.class)
    public ProblemDetail handleJwtAndSignatureException(JwtAndSignatureHandler ex) {
        ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.UNAUTHORIZED);
        problemDetail.setTitle("Unauthorized");
        problemDetail.setDetail(ex.getMessage());
        problemDetail.setProperty("timestamp", System.currentTimeMillis());
        return problemDetail;
    }

    @ExceptionHandler(InvalidOtpException.class)
    public ProblemDetail handleInvalidOtp(InvalidOtpException ex){
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

//    @ExceptionHandler(Exception.class)
//    public ProblemDetail handleGenericException(Exception ex) {
//        ProblemDetail problemDetail = ProblemDetail.forStatus(HttpStatus.INTERNAL_SERVER_ERROR);
//        problemDetail.setTitle("Internal Server Error");
//        problemDetail.setDetail("An unexpected error occurred: " + ex.getMessage());
//        return problemDetail;
//    }
}
