package com.abdr.exceptions;

public class SecretKeyGeneratingException extends Throwable {
    public SecretKeyGeneratingException(String s) {
        super(s);
    }
}
