package com.abdr.service;

import com.abdr.auth.entities.User;
import com.abdr.auth.entities.UserRole;
import com.abdr.auth.repositories.UserRepository;
import com.abdr.auth.services.JwtService;
import com.abdr.auth.services.RefreshTokenService;
import com.abdr.auth.utils.AuthResponse;
import com.abdr.auth.utils.LoginRequest;
import com.abdr.auth.utils.RegisterRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final RefreshTokenService refreshTokenService;
    private final JwtService jwtService;

    public AuthResponse register(RegisterRequest registerRequest){
        var user= User.builder()
                .name(registerRequest.getName())
                .email(registerRequest.getEmail())
                .username(registerRequest.getUsername())
                .password(passwordEncoder.encode(registerRequest.getPassword()))
                .role(UserRole.USER)
                .build();

        var savedUser=userRepository.save(user);
        var accessToken=jwtService.generateToken(savedUser.getUsername());
        var refreshToken=refreshTokenService.createRefreshToken(savedUser.getUsername());

        return AuthResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken.getRefreshToken())
                .build();
    }

    public AuthResponse login(LoginRequest loginRequest){
        var user=userRepository.findByEmail(loginRequest.getEmail()).orElseThrow(()->new UsernameNotFoundException("Email Not found with email : "+loginRequest.getEmail()));
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getEmail(),loginRequest.getPassword()));
        //var user=userRepository.findByEmail(loginRequest.getEmail()).orElseThrow(()->new UsernameNotFoundException("Email Not found with email : "+loginRequest.getEmail()));
        var accessToken=jwtService.generateToken(user.getUsername());
//        var refreshToken=refreshTokenService.createRefreshToken(user.getUsername());
        var refreshToken=refreshTokenService.createRefreshToken(loginRequest.getEmail());

        return AuthResponse.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken.getRefreshToken())
                .build();
    }
}
