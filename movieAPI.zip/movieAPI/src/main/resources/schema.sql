CREATE TABLE movie (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    director VARCHAR(255) NOT NULL,
    studio VARCHAR(255) NOT NULL,
    release_year INT NOT NULL,
    poster VARCHAR(255) NOT NULL
);

CREATE TABLE movie_cast (
    movie_id INT NOT NULL,
    movie_cast VARCHAR(255) NOT NULL,
    FOREIGN KEY (movie_id) REFERENCES movie(movie_id) ON DELETE CASCADE
);
