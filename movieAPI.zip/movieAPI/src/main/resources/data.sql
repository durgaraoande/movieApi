-- Inserting movies
INSERT INTO movie (title, director, studio, release_year, poster)
VALUES
('Inception', 'Christopher Nolan', 'Warner Bros.', 2010, 'inception_poster.jpg'),
('The Matrix', 'Lana Wachowski, Lilly Wachowski', 'Warner Bros.', 1999, 'matrix_poster.jpg');

-- Inserting movie casts
INSERT INTO movie_cast (movie_id, movie_cast)
VALUES
(1, 'Leonardo DiCaprio'),
(1, 'Joseph Gordon-Levitt'),
(1, 'Elliot Page'),
(2, 'Keanu Reeves'),
(2, 'Carrie-Anne Moss'),
(2, 'Laurence Fishburne');
